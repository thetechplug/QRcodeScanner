package tech.coveje.app.qrcodescanner;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;


import com.google.zxing.Result;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import me.dm7.barcodescanner.zxing.ZXingScannerView;


public class MainActivity extends AppCompatActivity implements ZXingScannerView.ResultHandler {
    private static final String TAG = "ScanActivity";
    private ZXingScannerView zXingScannerView;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        scan(zXingScannerView);
        Log.d(TAG, "onCreate:Scan Activity Started ");

    }
    //function to scan
    public void scan(View view){
        zXingScannerView= new ZXingScannerView(getApplicationContext());
        setContentView(zXingScannerView);
        zXingScannerView.setResultHandler(this);
        zXingScannerView.startCamera();
    }

    @Override
    //function to stop camera when camera is inactive
    protected void onPause() {
        super.onPause();
        zXingScannerView.stopCamera();
    }

    @Override
    //function to handle qr code scan result
    public void handleResult(Result result) {
        Toast.makeText(getApplicationContext(),result.getText(),Toast.LENGTH_SHORT).show();
        zXingScannerView.resumeCameraPreview(this);
    }
}
